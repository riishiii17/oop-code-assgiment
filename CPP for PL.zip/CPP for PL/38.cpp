#include <iostream>

int main() {
    int a, b;

    std::cout << "Enter two positive integers: ";
    std::cin >> a >> b;

    while (a != b) {
        if (a > b) {
            a -= b;
        } else {
            b -= a;
        }
    }

    std::cout << "GCD is: " << a << std::endl;

    return 0;
}
