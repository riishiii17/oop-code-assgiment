#include <iostream>

int main() {
    int num, i = 1;

    std::cout << "Enter a number: ";
    std::cin >> num;

    std::cout << "Multiplication table of " << num << ":\n";

    do {
        std::cout << num << " x " << i << " = " << num * i << std::endl;
        ++i;
    } while (i <= 10);

    return 0;
}
