#include <iostream>

int main() {
    const int x = 10;
    std::cout << "Original constant value: " << x << std::endl;

    int* ptr = const_cast<int*>(&x);
    *ptr = 20;

    std::cout << "Modified value through const_cast: " << x << std::endl;

    return 0;
}
