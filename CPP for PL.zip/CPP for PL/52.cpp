#include <iostream>
#include <cctype>

int main() {
    std::string str;
    int vowels = 0, consonants = 0;

    std::cout << "Enter a string: ";
    std::getline(std::cin, str);

    for (char ch : str) {
        if (std::isalpha(ch)) {
            char lowerCh = std::tolower(ch);
            if (lowerCh == 'a' || lowerCh == 'e' || lowerCh == 'i' || lowerCh == 'o' || lowerCh == 'u') {
                ++vowels;
            } else {
                ++consonants;
            }
        }
    }

    std::cout << "Number of vowels: " << vowels << std::endl;
    std::cout << "Number of consonants: " << consonants << std::endl;

    return 0;
}
