#include <iostream>
#include <string>
#include <map>

int main() {
    std::string input;
    std::cout << "Enter a string: ";
    std::getline(std::cin, input);

    std::map<char, int> frequency;

    for (char c : input) {
        frequency[c]++;
    }

    std::cout << "\nCharacter frequencies:\n";
    for (const auto& pair : frequency) {
        std::cout << "'" << pair.first << "': " << pair.second << '\n';
    }

    return 0;
}
