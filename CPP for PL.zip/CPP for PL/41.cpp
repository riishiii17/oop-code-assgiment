#include <iostream>

int main() {
    int num, originalNum, reversed = 0;

    std::cout << "Enter a number: ";
    std::cin >> num;

    originalNum = num;

    while (num != 0) {
        int digit = num % 10;
        reversed = reversed * 10 + digit;
        num /= 10;
    }

    if (originalNum == reversed) {
        std::cout << originalNum << " is a palindrome." << std::endl;
    } else {
        std::cout << originalNum << " is not a palindrome." << std::endl;
    }

    return 0;
}
