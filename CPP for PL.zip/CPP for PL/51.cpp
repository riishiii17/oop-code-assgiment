#include <iostream>

int main() {
    int sumEven = 0;
    int sumOdd = 0;

    for (int i = 1; i <= 100; ++i) {
        if (i % 2 == 0) {
            sumEven += i;
        }
    }

    for (int i = 1; i <= 100; ++i) {
        if (i % 2 != 0) {
            sumOdd += i;
        }
    }

    std::cout << "Sum of even numbers between 1 and 100: " << sumEven << std::endl;
    std::cout << "Sum of odd numbers between 1 and 100: " << sumOdd << std::endl;

    return 0;
}
