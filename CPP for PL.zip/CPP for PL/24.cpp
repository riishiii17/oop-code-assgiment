#include <iostream>

int main() {
    int num = 65;
    char ch = *reinterpret_cast<char*>(&num);

    std::cout << "Integer value: " << num << std::endl;
    std::cout << "Character value after reinterpret_cast: " << ch << std::endl;

    return 0;
}
