#include <iostream>

int main() {
    int intValue = 42;

    double doubleValue = static_cast<double>(intValue);
    std::cout << "Int to double conversion: " << doubleValue << std::endl;

    double anotherDouble = 3.14159;
    
    int anotherInt = static_cast<int>(anotherDouble);
    std::cout << "Double to int conversion: " << anotherInt << std::endl;

    return 0;
}
