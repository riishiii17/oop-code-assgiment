#include <iostream>
#include <string>

int main() {
    int num;
    std::string binary = "";

    std::cout << "Enter a decimal number: ";
    std::cin >> num;

    if (num == 0) {
        binary = "0";
    } else {
        while (num > 0) {
            binary = std::to_string(num % 2) + binary;
            num /= 2;
        }
    }

    std::cout << "Binary representation: " << binary << std::endl;

    return 0;
}
