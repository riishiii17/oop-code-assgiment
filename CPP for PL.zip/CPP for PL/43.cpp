#include <iostream>

int main() {
    int n;

    std::cout << "Enter the number of even numbers to print: ";
    std::cin >> n;

    std::cout << "First " << n << " even numbers are: ";

    for (int i = 1; i <= n; ++i) {
        std::cout << 2 * i << " ";
    }

    std::cout << std::endl;

    return 0;
}
