#include <iostream>

int main() {
    int num = 42;
    double d = (double)num;

    std::cout << "Integer value: " << num << std::endl;
    std::cout << "Double value after C-style cast: " << d << std::endl;

    return 0;
}
