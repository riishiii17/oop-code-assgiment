#include <iostream>

int main() {
    int num, count = 0;

    std::cout << "Enter a number: ";
    std::cin >> num;

    if (num == 0) {
        count = 1;
    } else {
        while (num != 0) {
            num /= 10;
            ++count;
        }
    }

    std::cout << "Number of digits: " << count << std::endl;

    return 0;
}
