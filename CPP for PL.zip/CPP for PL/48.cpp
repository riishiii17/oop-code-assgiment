#include <iostream>
#include <cmath>

int main() {
    int num, originalNum, remainder, result = 0, digits = 0;

    std::cout << "Enter a number: ";
    std::cin >> num;

    originalNum = num;

    while (originalNum != 0) {
        originalNum /= 10;
        ++digits;
    }

    originalNum = num;

    while (originalNum != 0) {
        remainder = originalNum % 10;
        result += std::pow(remainder, digits);
        originalNum /= 10;
    }

    if (result == num) {
        std::cout << num << " is an Armstrong number." << std::endl;
    } else {
        std::cout << num << " is not an Armstrong number." << std::endl;
    }

    return 0;
}
