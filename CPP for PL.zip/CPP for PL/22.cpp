#include <iostream>
using namespace std;

class Animal {
public:
    virtual void speak() {
        cout << "Animal speaks!" << endl;
    }

    virtual ~Animal() {}
};

class Dog : public Animal {
public:
    void speak() override {
        cout << "Dog barks!" << endl;
    }

    void fetch() {
        cout << "Dog fetches the ball!" << endl;
    }
};

class Cat : public Animal {
public:
    void speak() override {
        cout << "Cat meows!" << endl;
    }

    void climb() {
        cout << "Cat climbs the tree!" << endl;
    }
};

int main() {
    Animal* animal = new Dog();

    // Safe downcasting using dynamic_cast
    Dog* dogPtr = dynamic_cast<Dog*>(animal);
    if (dogPtr) {
        cout << "Downcast to Dog successful." << endl;
        dogPtr->speak();
        dogPtr->fetch();
    } else {
        cout << "Downcast to Dog failed." << endl;
    }

    // Trying invalid downcast
    Cat* catPtr = dynamic_cast<Cat*>(animal);
    if (catPtr) {
        cout << "Downcast to Cat successful." << endl;
        catPtr->speak();
        catPtr->climb();
    } else {
        cout << "Downcast to Cat failed (animal is not a Cat)." << endl;
    }

    delete animal;
    return 0;
}
