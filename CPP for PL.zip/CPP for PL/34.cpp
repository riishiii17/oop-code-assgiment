#include <iostream>

int main() {
    int sum = 0;

    for (int i = 2; i <= 100; i += 2) {
        sum += i;
    }

    std::cout << "Sum of all even numbers between 1 and 100 is: " << sum << std::endl;

    return 0;
}
