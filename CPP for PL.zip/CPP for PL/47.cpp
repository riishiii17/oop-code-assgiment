#include <iostream>
#include <string>

int main() {
    std::string str, reversed;

    std::cout << "Enter a string: ";
    std::getline(std::cin, str);

    for (int i = str.length() - 1; i >= 0; --i) {
        reversed += str[i];
    }

    std::cout << "Reversed string: " << reversed << std::endl;

    return 0;
}
