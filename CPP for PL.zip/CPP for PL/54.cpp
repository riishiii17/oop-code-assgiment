#include <iostream>
#include <cmath>

bool isPrime(int num) {
    if (num <= 1) return false;
    for (int i = 2; i <= std::sqrt(num); ++i) {
        if (num % i == 0) return false;
    }
    return true;
}

int main() {
    int start, end;

    std::cout << "Enter the start number: ";
    std::cin >> start;
    std::cout << "Enter the end number: ";
    std::cin >> end;

    std::cout << "Prime numbers between " << start << " and " << end << " are: " << std::endl;

    for (int num = start; num <= end; ++num) {
        if (isPrime(num)) {
            std::cout << num << " ";
        }
    }
    std::cout << std::endl;

    return 0;
}
