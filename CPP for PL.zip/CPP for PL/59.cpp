#include <iostream>

int main() {
    int num1, num2, max;

    std::cout << "Enter two numbers: ";
    std::cin >> num1 >> num2;

    max = (num1 > num2) ? num1 : num2;

    while (true) {
        if (max % num1 == 0 && max % num2 == 0) {
            std::cout << "LCM of " << num1 << " and " << num2 << " is " << max << std::endl;
            break;
        }
        ++max;
    }

    return 0;
}
