#include <iostream>

int main() {
    int arr[] = {1, 2, 3, 2, 4, 5, 1, 6};
    int n = sizeof(arr) / sizeof(arr[0]);
    bool foundDuplicate = false;

    std::cout << "Duplicate elements in the array are: ";

    for (int i = 0; i < n - 1; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (arr[i] == arr[j]) {
                std::cout << arr[i] << " ";
                foundDuplicate = true;
                break;
            }
        }
    }

    if (!foundDuplicate) {
        std::cout << "No duplicates found.";
    }

    std::cout << std::endl;

    return 0;
}
