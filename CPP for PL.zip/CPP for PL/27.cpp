#include <iostream>

int main() {
    int sum = 0;
    int i = 1;

    while (i <= 50) {
        sum += i;
        ++i;
    }

    std::cout << "Sum of the first 50 natural numbers is: " << sum << std::endl;

    return 0;
}
