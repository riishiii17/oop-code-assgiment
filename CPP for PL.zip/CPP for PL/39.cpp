#include <iostream>
#include <cmath>

int main() {
    std::cout << "Prime numbers between 1 and 100 are: " << std::endl;

    for (int num = 2; num <= 100; ++num) {
        bool isPrime = true;
        for (int i = 2; i <= std::sqrt(num); ++i) {
            if (num % i == 0) {
                isPrime = false;
                break;
            }
        }
        if (isPrime) {
            std::cout << num << " ";
        }
    }
    std::cout << std::endl;

    return 0;
}
